package ch.tbz.modul226.modul226a.musicplayer;

public class Main {
  public static void main(String[] args) {
    InputManager inputManager = new InputManager();
    inputManager.startManager();
  }
}
