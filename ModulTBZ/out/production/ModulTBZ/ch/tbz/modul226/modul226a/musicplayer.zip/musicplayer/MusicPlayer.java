package ch.tbz.modul226.modul226a.musicplayer;

import javazoom.jlgui.basicplayer.BasicPlayer;
import javazoom.jlgui.basicplayer.BasicPlayerException;
import java.io.File;
import java.net.MalformedURLException;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
/*
 * This is the class MusicPlayer. It has methods for playing, shuffling, deleting and stopping music
 * @author suhejl
* @version 1.0
* */
public class MusicPlayer {
  public ArrayList<String> musicList = new ArrayList<>();
  private String musicURL = "C:/Work/Source/projectsintelliJ/ModulTBZ" +
      "/src/music";
  private BasicPlayer player = new BasicPlayer();
  private File folder;

  public MusicPlayer() {
    folder = new File(musicURL);
    File[] listOfFiles = folder.listFiles(i -> i.isFile() && musicList.add(i.getName()));
    Collections.sort(musicList);
  }

  public void showMusic() {
    for (int i = 0; i < musicList.size(); i++) {
      System.out.println(i + 1 + ".\t" + musicList.get(i));
    }
  }

  public void playMusic(int id) {
    try {
      player.stop();
      selectMusic(musicList, id);
    } catch (BasicPlayerException basicex) {
      basicex.printStackTrace();
    }
  }

  public void shuffleMusic() {
      ArrayList<String> secondList = new ArrayList<>();
      secondList.addAll(musicList);
      Collections.shuffle(secondList);
      stopMusic();
      selectMusic(secondList, 0);
  }

  private void selectMusic(ArrayList<String> list, int id) {
    String songName = list.get(id);
    try {
      player.open(new URL("file:///" + musicURL + "/" + songName));
      player.play();
    } catch (BasicPlayerException | MalformedURLException e) {
      e.printStackTrace();
    }
  }

  public void stopMusic() {
    try {
      player.stop();
    } catch (BasicPlayerException basicex) {
      basicex.printStackTrace();
    }
  }

  public File stopToDeleteMusic(int id) {
    stopMusic();
    File file= new File(folder + "/" + musicList.get(id));;
    return file;
  }

  public void deleteMusic(int id) {
    File file = stopToDeleteMusic(id);
    if (file.isFile()) {
      file.delete();
    }
    musicList.remove(id);
  }
}
