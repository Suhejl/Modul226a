package ch.tbz.modul226.modul226a.musicplayer;

public class Music {
}
